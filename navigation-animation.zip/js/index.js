/*

Inspiration from:
https://tympanus.net/codrops/2013/08/06/creative-link-effects/

NOTE: For everyone who asks, I didn't copy the code, it's all my code and just inspired by the Codrops.

Comment for any ideas :)

*/